"use client";

import { useSearchParams, useRouter, usePathname } from "next/navigation";

interface PackageDetailsClientProps {
  packageData: any;
}

export default function PackageDetailsClientComp({
  packageData,
}: PackageDetailsClientProps) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const menuIdParam = searchParams.get("menu");

  const selectedMenu = menuIdParam
    ? packageData.menus.find(
        (menu: any) => menu._id === menuIdParam
      ) || null
    : null;

  const handleOpenMenu = (id: string) => {
    const params = new URLSearchParams(searchParams.toString());

    params.set("menu", id);

    router.push(`${pathname}?${params.toString()}`, {
      scroll: false,
    });
  };

  const handleCloseMenu = () => {
    const params = new URLSearchParams(searchParams.toString());

    params.delete("menu");

    const query = params.toString();

    router.push(
      query ? `${pathname}?${query}` : pathname,
      {
        scroll: false,
      }
    );
  };

  return (
    <div>
      <h1>{packageData.title}</h1>

      {packageData.menus.map((menu: any) => (
        <button
          key={menu._id}
          onClick={() => handleOpenMenu(menu._id)}
        >
          {menu.title}
        </button>
      ))}

      {selectedMenu && (
        <div
          className="fixed inset-0 bg-black/70"
          onClick={handleCloseMenu}
        >
          <div onClick={(e) => e.stopPropagation()}>
            <button onClick={handleCloseMenu}>
              بستن
            </button>

            <h2>{selectedMenu.title}</h2>

            {selectedMenu.description && (
              <p>{selectedMenu.description}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}