import PackageDetailsClientComp from "@/components/Site/PackageDetailsClient/PackageDetailsClientComp";
import { notFound } from "next/navigation";


interface PageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function PackagePage({ params }: PageProps) {
  const { slug } = await params;

  const response = await fetch(
    `${process.env.NEXT_PUBLIC_BASE_URL}/api/packages`,
    {
      cache: "no-store",
    }
  );

  if (!response.ok) {
    throw new Error("خطا در دریافت پکیج‌ها");
  }

  const data = await response.json();

  const packageData = data.packages?.find(
    (pkg: any) => pkg.slug === slug
  );

  if (!packageData) {
    notFound();
  }

  return <PackageDetailsClientComp packageData={packageData} />;
}